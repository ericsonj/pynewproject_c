/*
 * main.c
 *
 *  Created on: <%= date %>
 *      Author: <%= author %>
 */
#include <stdio.h>


int main() {
	printf("Hello pymaketool!!\n");
	return 0;
}


